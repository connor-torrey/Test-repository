/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#include "vt3_runtime.h"
#include "vt3_BMP__RedButtonStyle1_0_0.h"


/* file name:               red_button_style_1.png */
/* format:                  disk file */
/* file size:               4940 bytes */
/* MD5 signature:           f620bf4c186215677bff05b14d483d8a */
const UINT8 FAR vt3_BMP__RedButtonStyle1_0_0[] = "red_button_style_1.png";



/* end of file */
