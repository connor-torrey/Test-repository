/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_POU_H
#define INCLUDE__VT3_POU_H

#include "vt3_POU_common.h"

#endif /* INCLUDE__VT3_POU_H */

/* end of file */
