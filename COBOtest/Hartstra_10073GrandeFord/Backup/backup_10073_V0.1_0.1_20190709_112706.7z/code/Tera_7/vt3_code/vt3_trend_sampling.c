/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_TREND_SAMPLING_C
#define INCLUDE__VT3_TREND_SAMPLING_C

#include "vt3_vars.h"
#include "vt3_trend.h"

/* trend indicator sampling functions */
void vt3_trend_sampling_init(void)
{

};

void vt3_trend_sampling(void)
{
	float sample  = 0.0;

};

#endif /* INCLUDE__VT3_TREND_SAMPLING_C */

/* end of file */
