/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_EVENT__CAMERA_H
#define INCLUDE__VT3_EVENT__CAMERA_H

#include "vt3_base.h"

/* timer event handler for screen: /project/Tera_7/Screens/camera */
void vt3_event_ind_camera(BYTE event)
;

#endif /* INCLUDE__VT3_EVENT__CAMERA_H */

/* end of file */
