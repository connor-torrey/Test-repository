/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_DISP_H
#define INCLUDE__VT3_DISP_H

#include "vt3_base.h"
#include "vt3_images.h"
#include "vt3_lang.h"
#include "vt3_fonts.h"

#include "vt3_Disp__ScreenFrame.h"
#include "vt3_Event__ScreenFrame.h"

#include "vt3_Disp__Splash.h"
#include "vt3_Event__Splash.h"

#include "vt3_Disp__Home.h"
#include "vt3_Event__Home.h"

#include "vt3_Disp__Setup.h"
#include "vt3_Event__Setup.h"

#include "vt3_Disp__Camera.h"
#include "vt3_Event__Camera.h"

#include "vt3_Disp__Camera2.h"
#include "vt3_Event__Camera2.h"

#include "vt3_disp_common.h"

#endif /* INCLUDE__VT3_DISP_H */

/* end of file */
