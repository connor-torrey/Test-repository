/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_IMAGES_H
#define INCLUDE__VT3_IMAGES_H

#include "vt3_base.h"
#include "vt3_palette.h"
#include "vt3_BMP__BluButtonStyle1_0_0.h"
#include "vt3_BMP__GrnButtonStyle1_0_0.h"
#include "vt3_BMP__GryButtonStyle1_0_0.h"
#include "vt3_BMP__HartstraLogo1_0_0.h"
#include "vt3_BMP__HartstraLogo2_0_0.h"
#include "vt3_BMP__RedButtonStyle1_0_0.h"
#include "vt3_BMP__YlwButtonStyle1_0_0.h"

#endif /* INCLUDE__VT3_IMAGES_H */

/* end of file */
