/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#include "vt3_runtime.h"
#include "vt3_BMP__HartstraLogo1_0_0.h"


/* file name:               hartstra logo 1.png */
/* format:                  disk file */
/* file size:               74848 bytes */
/* MD5 signature:           e4e4dd6c1eb09ac4d021b3d1ad3aaa19 */
const UINT8 FAR vt3_BMP__HartstraLogo1_0_0[] = "hartstra logo 1.png";



/* end of file */
