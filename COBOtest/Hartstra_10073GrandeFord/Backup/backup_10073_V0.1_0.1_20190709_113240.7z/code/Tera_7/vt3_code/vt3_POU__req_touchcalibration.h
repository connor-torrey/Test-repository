/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_POU__REQ_TOUCHCALIBRATION_H
#define INCLUDE__VT3_POU__REQ_TOUCHCALIBRATION_H

#include "vt3_base.h"
#include "vt3_POU_string_typedef.h"



/* FUNCTION declaration */
DINT req_touchcalibration(void) ;




#endif /* INCLUDE__VT3_POU__REQ_TOUCHCALIBRATION_H */

/* end of file */
