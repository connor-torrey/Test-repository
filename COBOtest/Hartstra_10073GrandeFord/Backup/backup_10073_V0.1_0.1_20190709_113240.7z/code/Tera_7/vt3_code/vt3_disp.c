/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_DISP_C
#define INCLUDE__VT3_DISP_C

/* include source files for each screen */
#include "vt3_Disp__Camera.c"
#include "vt3_Disp__Camera2.c"
#include "vt3_Disp__Home.c"
#include "vt3_Disp__ScreenFrame.c"
#include "vt3_Disp__Setup.c"
#include "vt3_Disp__Splash.c"

#include "vt3_disp_common.c"

#include "vt3_trend_sampling.c"

#endif /* INCLUDE__VT3_DISP_C */

/* end of file */
