/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* vt3 version:  8.9.1.2-PATCH */
/* this file has been generated automatically by vt3 - do not modify! */

#include "vt3_runtime.h"


/* the software signature */
const unsigned char FAR vt3_signature_software[16] = {
	0xD7, 0x6F, 0x35, 0xF0, 0x6A, 0x9C, 0x2C, 0x4D, 0x7D, 0x97, 0x86, 0x86, 0xAC, 0x15, 0x7D, 0xC1
};



/* end of file */
