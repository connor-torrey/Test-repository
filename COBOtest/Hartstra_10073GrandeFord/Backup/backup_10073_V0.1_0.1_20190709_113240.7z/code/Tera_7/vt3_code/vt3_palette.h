/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_PALETTE_H
#define INCLUDE__VT3_PALETTE_H

#include "vt3_base.h"


/* code generator format:   5 */
/* screen colour model is:  colour 16 bits (RGB565) */
/* no palette for this screen colour model */


#endif /* INCLUDE__VT3_PALETTE_H */

/* end of file */
