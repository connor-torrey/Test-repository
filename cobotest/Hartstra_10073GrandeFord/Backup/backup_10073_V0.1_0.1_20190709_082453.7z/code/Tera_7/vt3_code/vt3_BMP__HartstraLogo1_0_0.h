/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_BMP__HARTSTRALOGO1_0_0_H
#define INCLUDE__VT3_BMP__HARTSTRALOGO1_0_0_H

#include "vt3_base.h"


/* colour image:            hartstra logo 1.png */
/* code generator format:   5 */
/* screen colour model is:  colour 16 bits (RGB565) */
/* file name:               hartstra logo 1.png */
/* format:                  disk file */
/* file size:               74848 bytes */
/* MD5 signature:           e4e4dd6c1eb09ac4d021b3d1ad3aaa19 */
extern const UINT8 FAR vt3_BMP__HartstraLogo1_0_0[];


#endif /* INCLUDE__VT3_BMP__HARTSTRALOGO1_0_0_H */

/* end of file */
