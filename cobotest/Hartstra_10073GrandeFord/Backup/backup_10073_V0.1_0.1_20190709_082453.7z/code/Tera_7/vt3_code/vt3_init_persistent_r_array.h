/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_INIT_PERSISTENT_R_ARRAY_H
#define INCLUDE__VT3_INIT_PERSISTENT_R_ARRAY_H

/* declaration of global function */

void initialize_bytearray_R(void);

/**************************************************************************/
#endif /* INCLUDE__VT3_INIT_PERSISTENT_R_ARRAY_H */

/* end of file */
