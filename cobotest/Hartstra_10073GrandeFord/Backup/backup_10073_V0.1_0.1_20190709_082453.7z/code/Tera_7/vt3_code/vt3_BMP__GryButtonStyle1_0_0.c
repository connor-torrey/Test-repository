/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#include "vt3_runtime.h"
#include "vt3_BMP__GryButtonStyle1_0_0.h"


/* file name:               gry_button_style_1.png */
/* format:                  disk file */
/* file size:               5041 bytes */
/* MD5 signature:           0a9ec07ea28d77526275b4f0647a8603 */
const UINT8 FAR vt3_BMP__GryButtonStyle1_0_0[] = "gry_button_style_1.png";



/* end of file */
