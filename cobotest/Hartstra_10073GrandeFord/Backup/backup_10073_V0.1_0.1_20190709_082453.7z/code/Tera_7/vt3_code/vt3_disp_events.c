/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_DISP_EVENTS_C
#define INCLUDE__VT3_DISP_EVENTS_C

/* include source files for each screen */
#include "vt3_Event__Camera.c"
#include "vt3_Event__Camera2.c"
#include "vt3_Event__Home.c"
#include "vt3_Event__ScreenFrame.c"
#include "vt3_Event__Setup.c"
#include "vt3_Event__Splash.c"
#endif /* INCLUDE__VT3_DISP_EVENTS_C */

/* end of file */
