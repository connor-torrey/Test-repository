/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* vt3 version:  8.9.0.6-PATCH */
/* this file has been generated automatically by vt3 - do not modify! */

#include "vt3_runtime.h"


/* the software signature */
const unsigned char FAR vt3_signature_software[16] = {
	0x7E, 0x55, 0x6A, 0x6F, 0xE0, 0x04, 0x24, 0xD9, 0x2E, 0xC5, 0x95, 0x17, 0xD4, 0x4A, 0x5B, 0x4A
};



/* end of file */
